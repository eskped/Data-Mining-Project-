How to run: 
- python main.py
- This creates a CSV file named s4761372.csv


Operation system:
- macOS Ventura 13.0


Programming language:
- Python 3.9.7


Packages installed needed to run the code with the version on my computer:
- Pandas 1.4.2
- Numpy 1.21.2
- Scikit-learn 1.1.2